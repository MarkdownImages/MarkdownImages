//
//  ViewController.h
//  XFNewsContentDemo
//
//  Created by 徐亚非 on 16/8/19.
//  Copyright © 2016年 maxthon. All rights reserved.
//

#import "XFNewsListModel.h"

@interface ViewController : UIViewController

@end

