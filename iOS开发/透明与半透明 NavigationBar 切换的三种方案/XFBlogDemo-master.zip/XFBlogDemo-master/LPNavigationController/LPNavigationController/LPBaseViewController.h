//
//  LPBaseViewController.h
//  LPNavigationController
//
//  Created by XuYafei on 16/4/14.
//  Copyright © 2016年 loopeer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPBaseViewController : UIViewController

@end
