//
//  AppDelegate.h
//  LPNavigationController
//
//  Created by XuYafei on 16/4/13.
//  Copyright © 2016年 loopeer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

