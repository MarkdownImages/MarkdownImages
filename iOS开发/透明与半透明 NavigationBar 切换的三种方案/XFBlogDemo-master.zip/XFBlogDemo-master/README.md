# XFBlogDemo

This repository is all my blog Demo.

>[博客：xuyafei.cn](http://xuyafei.cn)  
[简书：jianshu.com/users/2555924d8c6e](http://www.jianshu.com/users/2555924d8c6e)  
[微博：weibo.com/xuyafei86](http://weibo.com/xuyafei86)  

---

1. [LPNavigationController](http://xuyafei.cn/post/cocoatouch/tou-ming-yu-ban-tou-ming-navigationbar-qie-huan-de-san-chong-fang-an)  
透明与半透明 NavigationBar 切换的三种方案  
2. [XFNewsContentDemo](http://xuyafei.cn/post/cocoatouch/tu-wen-hun-pai)  
使用 WebView + HTML + JavaScript + JSExport 实现图文混排